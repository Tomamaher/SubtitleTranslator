package com.example.subtitletranslator

/**
 * Minimal, tolerant parser/builder for the .srt subtitle format:
 *
 * 1
 * 00:00:01,000 --> 00:00:04,000
 * Line one
 * Line two
 *
 * 2
 * ...
 */
object SrtParser {

    fun parse(content: String): List<SrtEntry> {
        val normalized = content.replace("\r\n", "\n").replace("\r", "\n")
        val blocks = normalized.split(Regex("\n{2,}")).filter { it.isNotBlank() }
        val entries = mutableListOf<SrtEntry>()

        for (block in blocks) {
            val lines = block.split("\n")
            if (lines.size < 2) continue

            val index = lines[0].trim()
            val timeCode = lines[1].trim()
            if (!timeCode.contains("-->")) continue

            val text = if (lines.size > 2) {
                lines.subList(2, lines.size).joinToString("\n").trim()
            } else {
                ""
            }

            entries.add(SrtEntry(index, timeCode, text))
        }
        return entries
    }

    fun build(entries: List<SrtEntry>): String {
        val sb = StringBuilder()
        for (entry in entries) {
            sb.append(entry.index).append('\n')
            sb.append(entry.timeCode).append('\n')
            sb.append(entry.text).append("\n\n")
        }
        return sb.toString().trim() + "\n"
    }
}
