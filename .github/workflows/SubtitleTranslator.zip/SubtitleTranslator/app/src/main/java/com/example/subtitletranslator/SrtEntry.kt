package com.example.subtitletranslator

/**
 * A single subtitle block: an index number, a timecode line, and one or
 * more lines of text.
 */
data class SrtEntry(
    val index: String,
    val timeCode: String,
    val text: String
)
