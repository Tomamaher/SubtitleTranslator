package com.example.subtitletranslator

import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.TimeUnit

/**
 * Thin client around a DeepLX-compatible /translate endpoint.
 *
 * Request:  { "text": "...", "source_lang": "AUTO", "target_lang": "AR" }
 * Response: { "code": 200, "data": "translated text", ... }
 */
class DeepLXClient(private val endpoint: String = "https://deeplx.1stg.me/translate") {

    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(20, TimeUnit.SECONDS)
        .writeTimeout(20, TimeUnit.SECONDS)
        .build()

    private val jsonMedia = "application/json; charset=utf-8".toMediaType()

    @Throws(IOException::class)
    fun translate(text: String, sourceLang: String = "auto", targetLang: String = "AR"): String {
        if (text.isBlank()) return text

        val payload = JSONObject().apply {
            put("text", text)
            put("source_lang", sourceLang.uppercase())
            put("target_lang", targetLang.uppercase())
        }
        val body = payload.toString().toRequestBody(jsonMedia)

        val request = Request.Builder()
            .url(endpoint)
            .post(body)
            .addHeader("Content-Type", "application/json")
            .build()

        client.newCall(request).execute().use { response ->
            val bodyString = response.body?.string().orEmpty()
            if (!response.isSuccessful) {
                throw IOException("HTTP ${response.code}: $bodyString")
            }
            val json = JSONObject(bodyString)
            val code = json.optInt("code", -1)
            if (code != 200) {
                throw IOException("API error code $code: $bodyString")
            }
            return json.optString("data", text)
        }
    }
}
