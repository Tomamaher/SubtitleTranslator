package com.example.subtitletranslator

/**
 * Subtitle lines are often cut mid-sentence ("He went to the" / "store").
 * Translating each line in isolation produces awkward, orphaned phrases.
 *
 * This groups consecutive entries into full sentences (splitting on
 * sentence-ending punctuation), so each API call gets full context, then
 * splits the translated sentence back across the original lines by word
 * share. Timecodes are left untouched -- only the text is redistributed.
 */
object SubtitleGrouper {

    private val terminators = charArrayOf('.', '!', '?', '؟', '…', ':')
    private const val MAX_GROUP_SIZE = 6

    fun group(entries: List<SrtEntry>): List<List<SrtEntry>> {
        val groups = mutableListOf<List<SrtEntry>>()
        var current = mutableListOf<SrtEntry>()

        for (entry in entries) {
            current.add(entry)
            val trimmed = entry.text.trim()
            val endsSentence = trimmed.isEmpty() || terminators.contains(trimmed.last())
            if (endsSentence || current.size >= MAX_GROUP_SIZE) {
                groups.add(current)
                current = mutableListOf()
            }
        }
        if (current.isNotEmpty()) groups.add(current)
        return groups
    }

    /** Joins a group's lines into one string to send as a single translation request. */
    fun joinedText(group: List<SrtEntry>): String =
        group.joinToString(" ") { it.text.replace('\n', ' ').trim() }

    /**
     * Splits [translatedText] back across [group]'s entries, proportionally
     * to each entry's original word count. Any rounding remainder goes to
     * the last entry.
     */
    fun distribute(group: List<SrtEntry>, translatedText: String): List<SrtEntry> {
        if (group.size == 1) {
            return listOf(group[0].copy(text = translatedText))
        }

        val translatedWords = translatedText.trim().split(Regex("\\s+")).filter { it.isNotEmpty() }
        if (translatedWords.isEmpty()) {
            return group // nothing came back; keep originals for this group
        }

        val originalWordCounts = group.map { e ->
            e.text.trim().split(Regex("\\s+")).filter { it.isNotEmpty() }.size.coerceAtLeast(1)
        }
        val totalOriginalWords = originalWordCounts.sum()
        val totalTranslatedWords = translatedWords.size

        val counts = IntArray(group.size)
        var assigned = 0
        for (i in 0 until group.size - 1) {
            val share = (totalTranslatedWords.toDouble() * originalWordCounts[i] / totalOriginalWords)
                .toInt()
                .coerceIn(0, totalTranslatedWords - assigned)
            counts[i] = share
            assigned += share
        }
        counts[group.size - 1] = (totalTranslatedWords - assigned).coerceAtLeast(0)

        val result = mutableListOf<SrtEntry>()
        var pos = 0
        for (i in group.indices) {
            val take = counts[i].coerceAtMost(translatedWords.size - pos)
            val slice = translatedWords.subList(pos, pos + take).joinToString(" ")
            pos += take
            result.add(group[i].copy(text = slice))
        }
        return result
    }
}
