package com.example.subtitletranslator

import android.net.Uri
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.example.subtitletranslator.databinding.ActivityMainBinding
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.IOException
import java.util.concurrent.atomic.AtomicInteger

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private val deepLX = DeepLXClient()

    private var entries: List<SrtEntry> = emptyList()
    private var translatedEntries: List<SrtEntry> = emptyList()
    private val translationCache = mutableMapOf<String, String>()

    // Display name -> DeepL language code. "auto" lets DeepL detect it.
    private val sourceLanguages = listOf(
        "Auto detect" to "auto",
        "English" to "en",
        "French" to "fr",
        "Spanish" to "es",
        "German" to "de",
        "Russian" to "ru",
        "Turkish" to "tr",
        "Portuguese" to "pt",
        "Italian" to "it",
        "Chinese" to "zh",
        "Japanese" to "ja",
        "Korean" to "ko"
    )

    private val pickFileLauncher =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            uri?.let { onFilePicked(it) }
        }

    private val saveFileLauncher =
        registerForActivityResult(ActivityResultContracts.CreateDocument("application/x-subrip")) { uri ->
            uri?.let { saveTranslatedFile(it) }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.spinnerSource.adapter = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_dropdown_item,
            sourceLanguages.map { it.first }
        )

        binding.btnPick.setOnClickListener {
            pickFileLauncher.launch(arrayOf("*/*"))
        }

        binding.btnTranslate.setOnClickListener {
            startTranslation()
        }

        binding.btnSave.setOnClickListener {
            saveFileLauncher.launch("translated_ar.srt")
        }
    }

    private fun onFilePicked(uri: Uri) {
        try {
            val text = contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }
                ?: throw IOException("Could not read file")

            entries = SrtParser.parse(text).map { it.copy(text = TextUtils.dedupeRepeatedSegments(it.text)) }

            binding.tvFile.text = uri.lastPathSegment ?: "File selected"
            binding.tvCount.text = "${entries.size} subtitle entries found"
            binding.btnTranslate.isEnabled = entries.isNotEmpty()
            binding.btnSave.isEnabled = false
            binding.progressBar.progress = 0
            binding.tvProgress.text = ""

            if (entries.isEmpty()) {
                Toast.makeText(this, "No subtitle entries found in this file", Toast.LENGTH_LONG).show()
            }
        } catch (e: Exception) {
            Toast.makeText(this, "Failed to read file: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun startTranslation() {
        if (entries.isEmpty()) return

        binding.btnTranslate.isEnabled = false
        binding.btnSave.isEnabled = false
        binding.progressBar.max = entries.size
        binding.progressBar.progress = 0
        binding.tvProgress.text = "Translating 0 / ${entries.size}"

        val sourceLang = sourceLanguages[binding.spinnerSource.selectedItemPosition].second
        val done = AtomicInteger(0)
        val failed = AtomicInteger(0)
        val lastError = java.util.concurrent.atomic.AtomicReference<String?>(null)
        translationCache.clear()

        // Merge consecutive lines into full sentences before translating, so
        // DeepL sees complete context instead of a fragment like "He went to
        // the" / "store" -- and so we make far fewer API calls overall.
        val groups = SubtitleGrouper.group(entries)

        lifecycleScope.launch {
            // The free endpoint rate-limits aggressively -- even light
            // concurrency triggers HTTP 429. Process one group at a time.
            val groupResults = withContext(Dispatchers.IO) {
                groups.map { group ->
                    val joined = SubtitleGrouper.joinedText(group)
                    val translatedText = translateGroupText(joined, sourceLang, failed, lastError)
                    val distributed = SubtitleGrouper.distribute(group, translatedText)

                    val count = done.addAndGet(group.size)
                    withContext(Dispatchers.Main) {
                        binding.progressBar.progress = count.coerceAtMost(entries.size)
                        binding.tvProgress.text =
                            "Translating ${count.coerceAtMost(entries.size)} / ${entries.size}"
                    }

                    // Small pause between requests so we stay under the
                    // endpoint's rate limit even when nothing failed.
                    Thread.sleep(300)

                    distributed
                }
            }

            translatedEntries = groupResults.flatten().sortedBy { it.index.toIntOrNull() ?: 0 }

            binding.btnTranslate.isEnabled = true
            binding.btnSave.isEnabled = true

            val failCount = failed.get()
            binding.tvProgress.text = if (failCount == 0) {
                "Done! All ${entries.size} lines translated."
            } else {
                "Done. $failCount group(s) kept in the original language. " +
                    "Last error: ${lastError.get() ?: "unknown"}"
            }
        }
    }

    /**
     * Skips the API call entirely for pure sound/music cues, serves from
     * cache when this exact text was already translated earlier in the
     * same run (common with repeated dialogue lines), and otherwise calls
     * the API with retry.
     */
    private fun translateGroupText(
        joined: String,
        sourceLang: String,
        failed: AtomicInteger,
        lastError: java.util.concurrent.atomic.AtomicReference<String?>
    ): String {
        if (TextUtils.isNonTranslatable(joined)) {
            return joined
        }

        val cacheKey = "$sourceLang|$joined"
        translationCache[cacheKey]?.let { return it }

        val result = translateWithRetry(joined, sourceLang, failed, lastError)
        // Only cache text that actually came back from the API -- not a
        // fallback to the original after repeated failures (result is the
        // very same String object as `joined` in that case).
        if (result !== joined) {
            translationCache[cacheKey] = result
        }
        return result
    }

    private fun translateWithRetry(
        text: String,
        sourceLang: String,
        failed: AtomicInteger,
        lastError: java.util.concurrent.atomic.AtomicReference<String?>
    ): String {
        var attempt = 0
        while (attempt < 5) {
            try {
                return deepLX.translate(text, sourceLang, "AR")
            } catch (e: Exception) {
                lastError.set(e.message)
                attempt++
                val isRateLimited = e.message?.contains("429") == true
                val waitMs = if (isRateLimited) {
                    // Rate limits need real time to clear, not a quick retry.
                    2000L * attempt
                } else {
                    500L * attempt
                }
                try {
                    Thread.sleep(waitMs)
                } catch (_: InterruptedException) {
                }
            }
        }
        failed.incrementAndGet()
        return text // fall back to the original text if translation kept failing
    }

    private fun saveTranslatedFile(uri: Uri) {
        try {
            val content = SrtParser.build(translatedEntries)
            contentResolver.openOutputStream(uri)?.use { out ->
                out.write(content.toByteArray(Charsets.UTF_8))
            } ?: throw IOException("Could not open output stream")
            Toast.makeText(this, "Saved translated subtitles", Toast.LENGTH_LONG).show()
        } catch (e: Exception) {
            Toast.makeText(this, "Failed to save file: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }
}
