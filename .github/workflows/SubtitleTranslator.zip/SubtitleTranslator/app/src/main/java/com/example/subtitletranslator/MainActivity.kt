package com.example.subtitletranslator

import android.net.Uri
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.example.subtitletranslator.databinding.ActivityMainBinding
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import java.io.IOException
import java.util.concurrent.atomic.AtomicInteger

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private val deepLX = DeepLXClient()

    private var entries: List<SrtEntry> = emptyList()
    private var translatedEntries: List<SrtEntry> = emptyList()

    // Display name -> DeepL language code. "auto" lets DeepL detect it.
    private val sourceLanguages = listOf(
        "Auto detect" to "auto",
        "English" to "en",
        "French" to "fr",
        "Spanish" to "es",
        "German" to "de",
        "Russian" to "ru",
        "Turkish" to "tr",
        "Portuguese" to "pt",
        "Italian" to "it",
        "Chinese" to "zh",
        "Japanese" to "ja",
        "Korean" to "ko"
    )

    private val pickFileLauncher =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            uri?.let { onFilePicked(it) }
        }

    private val saveFileLauncher =
        registerForActivityResult(ActivityResultContracts.CreateDocument("application/x-subrip")) { uri ->
            uri?.let { saveTranslatedFile(it) }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.spinnerSource.adapter = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_dropdown_item,
            sourceLanguages.map { it.first }
        )

        binding.btnPick.setOnClickListener {
            pickFileLauncher.launch(arrayOf("*/*"))
        }

        binding.btnTranslate.setOnClickListener {
            startTranslation()
        }

        binding.btnSave.setOnClickListener {
            saveFileLauncher.launch("translated_ar.srt")
        }
    }

    private fun onFilePicked(uri: Uri) {
        try {
            val text = contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }
                ?: throw IOException("Could not read file")

            entries = SrtParser.parse(text)

            binding.tvFile.text = uri.lastPathSegment ?: "File selected"
            binding.tvCount.text = "${entries.size} subtitle entries found"
            binding.btnTranslate.isEnabled = entries.isNotEmpty()
            binding.btnSave.isEnabled = false
            binding.progressBar.progress = 0
            binding.tvProgress.text = ""

            if (entries.isEmpty()) {
                Toast.makeText(this, "No subtitle entries found in this file", Toast.LENGTH_LONG).show()
            }
        } catch (e: Exception) {
            Toast.makeText(this, "Failed to read file: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun startTranslation() {
        if (entries.isEmpty()) return

        binding.btnTranslate.isEnabled = false
        binding.btnSave.isEnabled = false
        binding.progressBar.max = entries.size
        binding.progressBar.progress = 0
        binding.tvProgress.text = "Translating 0 / ${entries.size}"

        val sourceLang = sourceLanguages[binding.spinnerSource.selectedItemPosition].second
        val done = AtomicInteger(0)
        val failed = AtomicInteger(0)
        val lastError = java.util.concurrent.atomic.AtomicReference<String?>(null)

        // Merge consecutive lines into full sentences before translating, so
        // DeepL sees complete context instead of a fragment like "He went to
        // the" / "store" -- and so we make far fewer API calls overall.
        val groups = SubtitleGrouper.group(entries)

        lifecycleScope.launch {
            // Fewer, larger calls now, so a modest concurrency is safe.
            val semaphore = Semaphore(3)

            val groupResults = withContext(Dispatchers.IO) {
                coroutineScope {
                    groups.map { group ->
                        async {
                            semaphore.withPermit {
                                val joined = SubtitleGrouper.joinedText(group)
                                val translatedText =
                                    translateWithRetry(joined, sourceLang, failed, lastError)
                                val distributed = SubtitleGrouper.distribute(group, translatedText)

                                val count = done.addAndGet(group.size)
                                withContext(Dispatchers.Main) {
                                    binding.progressBar.progress = count.coerceAtMost(entries.size)
                                    binding.tvProgress.text =
                                        "Translating ${count.coerceAtMost(entries.size)} / ${entries.size}"
                                }
                                distributed
                            }
                        }
                    }.awaitAll()
                }
            }

            // Groups can complete out of submission order; flatten then sort
            // by index to guarantee entries stay in the original order.
            translatedEntries = groupResults.flatten().sortedBy { it.index.toIntOrNull() ?: 0 }

            binding.btnTranslate.isEnabled = true
            binding.btnSave.isEnabled = true

            val failCount = failed.get()
            binding.tvProgress.text = if (failCount == 0) {
                "Done! All ${entries.size} lines translated."
            } else {
                "Done. $failCount group(s) kept in the original language. " +
                    "Last error: ${lastError.get() ?: "unknown"}"
            }
        }
    }

    private fun translateWithRetry(
        text: String,
        sourceLang: String,
        failed: AtomicInteger,
        lastError: java.util.concurrent.atomic.AtomicReference<String?>
    ): String {
        var attempt = 0
        while (attempt < 3) {
            try {
                return deepLX.translate(text, sourceLang, "AR")
            } catch (e: Exception) {
                lastError.set(e.message)
                attempt++
                try {
                    Thread.sleep(600L * attempt)
                } catch (_: InterruptedException) {
                }
            }
        }
        failed.incrementAndGet()
        return text // fall back to the original text if translation kept failing
    }

    private fun saveTranslatedFile(uri: Uri) {
        try {
            val content = SrtParser.build(translatedEntries)
            contentResolver.openOutputStream(uri)?.use { out ->
                out.write(content.toByteArray(Charsets.UTF_8))
            } ?: throw IOException("Could not open output stream")
            Toast.makeText(this, "Saved translated subtitles", Toast.LENGTH_LONG).show()
        } catch (e: Exception) {
            Toast.makeText(this, "Failed to save file: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }
}
