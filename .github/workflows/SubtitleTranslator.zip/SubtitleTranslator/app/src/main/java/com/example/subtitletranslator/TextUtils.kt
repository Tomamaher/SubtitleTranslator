package com.example.subtitletranslator

/**
 * Small text-cleanup helpers, ported from ideas used in a companion browser
 * extension that handles live subtitle streams:
 * - stripping stray markup and collapsing whitespace
 * - dropping duplicated phrases within a single cue (a common artifact in
 *   auto-generated captions, e.g. a caption redraw repeating a phrase)
 * - recognizing pure sound/music cues that don't need translating at all
 */
object TextUtils {

    private val htmlTagRegex = Regex("<[^>]+>")
    private val whitespaceRegex = Regex("\\s+")
    private val segmentSplitRegex = Regex("(?<=[.!?…])\\s+|\\s{2,}|\\n+")
    private val bracketedRegex = Regex("^[\\[(].*[\\])]$")

    fun normalize(text: String): String =
        text.replace(htmlTagRegex, " ")
            .replace(whitespaceRegex, " ")
            .trim()

    /**
     * Removes exact-duplicate segments within a single cue, e.g.
     * "I know. I know." collapses to "I know." Only removes repeats inside
     * the same cue -- never touches other cues, so intentional repetition
     * across the subtitle file (dialogue that repeats a line later) is
     * untouched.
     */
    fun dedupeRepeatedSegments(text: String): String {
        val normalized = normalize(text)
        if (normalized.isEmpty()) return ""

        val parts = normalized.split(segmentSplitRegex)
            .map { normalize(it) }
            .filter { it.isNotEmpty() }

        if (parts.size <= 1) return normalized

        val unique = mutableListOf<String>()
        for (part in parts) {
            if (part !in unique) {
                unique.add(part)
            }
        }
        return unique.joinToString(" ")
    }

    /**
     * True for lines that are pure sound-effect/music cues, e.g. "[Music]",
     * "(applause)", "♪ ♪". These don't need translation, so callers can
     * skip the API call for them entirely.
     */
    fun isNonTranslatable(text: String): Boolean {
        val trimmed = normalize(text)
        if (trimmed.isEmpty()) return true
        if (bracketedRegex.matches(trimmed)) return true
        return !trimmed.any { it.isLetter() } // just symbols/notes/numbers
    }
}
